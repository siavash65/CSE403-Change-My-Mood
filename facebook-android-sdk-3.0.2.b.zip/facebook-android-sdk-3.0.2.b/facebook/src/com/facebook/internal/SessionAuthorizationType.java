package com.facebook.internal;

public enum SessionAuthorizationType {
    READ,
    PUBLISH
}
